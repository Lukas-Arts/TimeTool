#!/bin/bash
cp ./TimeTool.jar ~/TimeTool/
cp ./tray.png ~/TimeTool/
cp ./time.props ~/TimeTool/
gksu cp ./timetool.sh /usr/bin/timetool
