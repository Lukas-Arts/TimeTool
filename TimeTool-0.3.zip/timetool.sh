#!/bin/bash
java -jar ./TimeTool.jar "$@"